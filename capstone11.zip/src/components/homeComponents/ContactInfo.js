import React from "react";

const ContactInfo = () => {
  return (
    <div className="ContactInfo">
      
    </div>
  );
};

export default ContactInfo;
