import React from "react";
import { Link } from "react-router-dom";

const Header = () => {
  return (
    <div>
      {/* Top Header */}
      <div className="Announcement ">
        <div className="container">
          <div className="row">
            <div className="col-md-6 d-flex align-items-center display-none">
              <Link to="">
                <b>Capstone</b>
              </Link>
            </div>
            <div className=" col-12 col-lg-6 justify-content-center justify-content-lg-end d-flex align-items-center">
              <Link to="">
                Home
              </Link>
              <Link to="">
                Products
              </Link>
              <Link to="">
                About Us
              </Link>
              <Link to="">
                Contact
              </Link>
            </div>
          </div>
        </div>
      </div> 
    </div>
  );
};

export default Header;
