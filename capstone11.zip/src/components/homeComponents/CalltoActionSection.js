import React from "react";

const CalltoActionSection = () => {
  return (
    <div className="subscribe-section bg-with-black">
      <h1 class="cap-text">Capstone is best Online Clothing Store</h1>
    </div>
  );
};

export default CalltoActionSection;
